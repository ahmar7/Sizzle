import Logo from "../assets/img/logo.png";
import newLogo from "../assets/img/newlogo.png";
import Arrow from "../assets/img/arrow.png";
import Card1 from "../assets/img/card1.png";
import Card2 from "../assets/img/card2.png";
import Card3 from "../assets/img/card3.png";
import Card4 from "../assets/img/card4.png";
import Card5 from "../assets/img/card5.png";
import Card6 from "../assets/img/card6.png";
import ArrowFaq from "../assets/img/arrow-faq.png";
import Inputarrow from "../assets/img/input-arrow.png";
import Tech1 from "../assets/img/1.png";
import Tech2 from "../assets/img/2.png";
import Animate from "../assets/img/animate.mp4";
export {
  newLogo,
  Logo,
  Arrow,
  Card1,
  Card2,
  Card3,
  Card4,
  Card5,
  Card6,
  ArrowFaq,
  Inputarrow,
  Tech1,
  Tech2,
  Animate,
};
