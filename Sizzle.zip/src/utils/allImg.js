import Logo from "../assets/img/logo.png";
import Arrow from "../assets/img/arrow.png";
import Card1 from "../assets/img/card1.png";
import Card2 from "../assets/img/card2.png";
import Card3 from "../assets/img/card3.png";
import Card4 from "../assets/img/card4.png";
import Card5 from "../assets/img/card5.png";
import Card6 from "../assets/img/card6.png";
import ArrowFaq from "../assets/img/arrow-faq.png";
import Inputarrow from "../assets/img//input-arrow.png";

export {
  Logo,
  Arrow,
  Card1,
  Card2,
  Card3,
  Card4,
  Card5,
  Card6,
  ArrowFaq,
  Inputarrow,
};
